import React, { useEffect, useRef, useState } from 'react';

declare global {
  interface Window {
    katex?: any;
    MathfieldElement?: any;
  }
  namespace React {
    namespace JSX {
      interface IntrinsicElements {
        'math-field': any;
      }
    }
  }
  namespace JSX {
    interface IntrinsicElements {
      'math-field': any;
    }
  }
}

// =========================================================================
// CƠ SỞ DỮ LIỆU KÝ HIỆU CỦA MS WORD (8 DANH MỤC SYMBOLS)
// =========================================================================
export const WORD_SYMBOLS: Record<string, string[]> = {
  basic: [
    '\\pm', '\\mp', '\\times', '\\div', '\\neq', '\\approx', '\\cong', '\\equiv', '\\propto',
    '<', '>', '\\le', '\\ge', '\\ll', '\\gg', '\\infty', '!', '\\forall',
    '\\exists', '\\nexists', '\\in', '\\notin', '\\ni', '\\partial', '\\nabla', '\\Delta', '\\emptyset',
    '\\cup', '\\cap', '\\%', '^\\circ', '\\therefore', '\\because', '\\alpha', '\\beta', '\\gamma',
    '\\delta', '\\epsilon', '\\theta', '\\lambda', '\\mu', '\\pi', '\\rho', '\\sigma', '\\phi', '\\omega'
  ],
  greek: [
    '\\alpha', '\\beta', '\\gamma', '\\delta', '\\epsilon', '\\varepsilon', '\\zeta', '\\eta', '\\theta',
    '\\vartheta', '\\iota', '\\kappa', '\\lambda', '\\mu', '\\nu', '\\xi', '\\pi', '\\rho',
    '\\varrho', '\\sigma', '\\varsigma', '\\tau', '\\upsilon', '\\phi', '\\varphi', '\\chi', '\\psi',
    '\\omega', '\\Gamma', '\\Delta', '\\Theta', '\\Lambda', '\\Xi', '\\Pi', '\\Sigma', '\\Upsilon',
    '\\Phi', '\\Psi', '\\Omega'
  ],
  letterlike: [
    '\\forall', '\\complement', '\\partial', '\\ell', '\\hbar', '\\Im', '\\Re', '\\wp', '\\aleph',
    '\\mathbb{N}', '\\mathbb{Z}', '\\mathbb{Q}', '\\mathbb{R}', '\\mathbb{C}', '\\mathcal{L}', '\\mathcal{F}', '\\mathcal{H}', '\\infty'
  ],
  operators: [
    '+', '-', '\\times', '\\div', '\\pm', '\\mp', '\\cdot', '\\ast', '\\circ',
    '\\bullet', '\\oplus', '\\ominus', '\\otimes', '\\oslash', '\\odot', '\\wedge', '\\vee', '\\cap',
    '\\cup', '\\uplus', '\\sqcap', '\\sqcup', '\\subset', '\\supset', '\\subseteq', '\\supseteq', '\\vdash', '\\models'
  ],
  arrows: [
    '\\leftarrow', '\\rightarrow', '\\uparrow', '\\downarrow', '\\leftrightarrow', '\\Leftarrow', '\\Rightarrow', '\\Uparrow', '\\Downarrow',
    '\\Leftrightarrow', '\\mapsto', '\\longleftarrow', '\\longrightarrow', '\\Longleftrightarrow', '\\nearrow', '\\searrow', '\\swarrow', '\\nwarrow',
    '\\rightleftharpoons', '\\hookleftarrow', '\\hookrightarrow'
  ],
  negated: [
    '\\neq', '\\nless', '\\ngtr', '\\nleq', '\\ngeq', '\\nsim', '\\ncong', '\\not\\equiv', '\\notin',
    '\\nsubseteq', '\\nsupseteq', '\\nparallel', '\\nmid', '\\nvdash'
  ],
  scripts: [
    '\\mathcal{A}', '\\mathcal{B}', '\\mathcal{C}', '\\mathcal{D}', '\\mathcal{E}', '\\mathcal{F}', '\\mathcal{G}', '\\mathcal{H}', '\\mathcal{I}',
    '\\mathcal{L}', '\\mathcal{M}', '\\mathcal{N}', '\\mathcal{O}', '\\mathcal{P}', '\\mathcal{R}', '\\mathcal{S}', '\\mathcal{T}', '\\mathcal{U}',
    '\\mathbb{A}', '\\mathbb{B}', '\\mathbb{C}', '\\mathbb{E}', '\\mathbb{F}', '\\mathbb{H}', '\\mathbb{N}', '\\mathbb{P}', '\\mathbb{Q}',
    '\\mathbb{R}', '\\mathbb{Z}'
  ],
  geometry: [
    '\\angle', '\\measuredangle', '\\sphericalangle', '\\perp', '\\parallel', '\\triangle', '\\square', '\\lozenge', '\\circ',
    '\\cong', '\\sim', '\\simeq', '\\equiv'
  ]
};

// =========================================================================
// CƠ SỞ DỮ LIỆU 11 MENU CẤU TRÚC CỦA MS WORD (STRUCTURES)
// preview: Vẽ nút bấm có ô vuông (\square)
// insert: Chèn vào khung nhập có ô giữ chỗ (#?)
// =========================================================================
export interface WordStructureItem {
  label: string;
  preview: string;
  insert: string;
}

export interface WordStructureSection {
  name: string;
  items: WordStructureItem[];
}

export interface WordStructureGroup {
  id: string;
  title: string;
  viTitle: string;
  icon: string;
  alignRight?: boolean;
  hasCustomMatrix?: boolean;
  sections: WordStructureSection[];
}

export const WORD_STRUCTURES: WordStructureGroup[] = [
  {
    id: 'fraction',
    title: 'Fraction',
    viTitle: 'Phân số',
    icon: '\\frac{\\square}{\\square}',
    sections: [
      {
        name: 'Phân số thông dụng (Common Fractions)',
        items: [
          { label: 'Phân số đứng', preview: '\\frac{\\square}{\\square}', insert: '\\frac{#?}{#?}' },
          { label: 'Phân số nghiêng', preview: '\\square / \\square', insert: '{#?}/{#?}' },
          { label: 'Phân số nhỏ', preview: '\\tfrac{\\square}{\\square}', insert: '\\tfrac{#?}{#?}' },
          { label: 'Đạo hàm dy/dx', preview: '\\frac{dy}{dx}', insert: '\\frac{d#?}{d#?}' },
          { label: 'Đạo hàm riêng', preview: '\\frac{\\partial y}{\\partial x}', insert: '\\frac{\\partial #?}{\\partial #?}' },
          { label: 'Số gia Delta', preview: '\\frac{\\Delta y}{\\Delta x}', insert: '\\frac{\\Delta #?}{\\Delta #?}' }
        ]
      }
    ]
  },
  {
    id: 'script',
    title: 'Script',
    viTitle: 'Chỉ số',
    icon: '\\square^{\\square}',
    sections: [
      {
        name: 'Số mũ và Chỉ số dưới (Subscripts & Superscripts)',
        items: [
          { label: 'Số mũ (Superscript)', preview: '\\square^{\\square}', insert: '{#?}^{#?}' },
          { label: 'Chỉ số dưới (Subscript)', preview: '\\square_{\\square}', insert: '{#?}_{#?}' },
          { label: 'Cả mũ và dưới', preview: '\\square_{\\square}^{\\square}', insert: '{#?}_{#?}^{#?}' },
          { label: 'Chỉ số bên trái', preview: '{}_{\\square}^{\\square}\\square', insert: '{}_{#?}^{#?}{#?}' },
          { label: 'Hàm mũ cơ số e', preview: 'e^{\\square}', insert: 'e^{#?}' },
          { label: 'Bình phương', preview: 'x^2', insert: '{#?}^2' }
        ]
      }
    ]
  },
  {
    id: 'radical',
    title: 'Radical',
    viTitle: 'Căn thức',
    icon: '\\sqrt{\\square}',
    sections: [
      {
        name: 'Các loại căn thức (Radicals)',
        items: [
          { label: 'Căn bậc hai', preview: '\\sqrt{\\square}', insert: '\\sqrt{#?}' },
          { label: 'Căn bậc n', preview: '\\sqrt[\\square]{\\square}', insert: '\\sqrt[#?]{#?}' },
          { label: 'Căn bậc ba', preview: '\\sqrt[3]{\\square}', insert: '\\sqrt[3]{#?}' },
          { label: 'Căn bậc bốn', preview: '\\sqrt[4]{\\square}', insert: '\\sqrt[4]{#?}' },
          { label: 'Công thức nghiệm bậc 2', preview: '\\frac{-b\\pm\\sqrt{b^2-4ac}}{2a}', insert: '\\frac{-#?\\pm\\sqrt{#?^2-4#?#?}}{2#?}' }
        ]
      }
    ]
  },
  {
    id: 'integral',
    title: 'Integral',
    viTitle: 'Tích phân',
    icon: '\\int_{\\square}^{\\square}',
    sections: [
      {
        name: 'Tích phân đơn, bội và đường (Integrals)',
        items: [
          { label: 'TP bất định', preview: '\\int \\square', insert: '\\int #? \\, d#?' },
          { label: 'TP xác định', preview: '\\int_{\\square}^{\\square} \\square', insert: '\\int_{#?}^{#?} #? \\, d#?' },
          { label: 'TP kép', preview: '\\iint \\square', insert: '\\iint #? \\, dxdy' },
          { label: 'TP kép có cận', preview: '\\iint_{\\square}^{\\square} \\square', insert: '\\iint_{#?}^{#?} #? \\, dxdy' },
          { label: 'TP bội ba', preview: '\\iiint \\square', insert: '\\iiint #? \\, dxdydz' },
          { label: 'TP đường kín', preview: '\\oint \\square', insert: '\\oint_{#?} #? \\, ds' },
          { label: 'TP suy rộng', preview: '\\int_{-\\infty}^{+\\infty} \\square', insert: '\\int_{-\\infty}^{+\\infty} #? \\, dx' }
        ]
      }
    ]
  },
  {
    id: 'largeop',
    title: 'Large Operator',
    viTitle: 'Toán tử lớn',
    icon: '\\sum_{\\square}^{\\square}',
    sections: [
      {
        name: 'Tổng, Tích, Hợp, Giao (Summations & Products)',
        items: [
          { label: 'Tổng có cận', preview: '\\sum_{\\square}^{\\square} \\square', insert: '\\sum_{#?}^{#?} #?' },
          { label: 'Tổng dưới', preview: '\\sum_{\\square} \\square', insert: '\\sum_{#?} #?' },
          { label: 'Tích Pi có cận', preview: '\\prod_{\\square}^{\\square} \\square', insert: '\\prod_{#?}^{#?} #?' },
          { label: 'Đối tích', preview: '\\coprod_{\\square}^{\\square} \\square', insert: '\\coprod_{#?}^{#?} #?' },
          { label: 'Hợp lớn (Union)', preview: '\\bigcup_{\\square}^{\\square} \\square', insert: '\\bigcup_{#?}^{#?} #?' },
          { label: 'Giao lớn (Intersection)', preview: '\\bigcap_{\\square}^{\\square} \\square', insert: '\\bigcap_{#?}^{#?} #?' }
        ]
      }
    ]
  },
  {
    id: 'bracket',
    title: 'Bracket',
    viTitle: 'Dấu ngoặc',
    icon: '\\left(\\square\\right)',
    sections: [
      {
        name: 'Dấu ngoặc co giãn & Hệ phương trình (Brackets & Cases)',
        items: [
          { label: 'Ngoặc tròn', preview: '\\left( \\square \\right)', insert: '\\left( #? \\right)' },
          { label: 'Ngoặc vuông', preview: '\\left[ \\square \\right]', insert: '\\left[ #? \\right]' },
          { label: 'Ngoặc nhọn', preview: '\\left\\{ \\square \\right\\}', insert: '\\left\\{ #? \\right\\}' },
          { label: 'Trị tuyệt đối', preview: '\\left| \\square \\right|', insert: '\\left| #? \\right|' },
          { label: 'Chuẩn (Norm)', preview: '\\left\\| \\square \\right\\|', insert: '\\left\\| #? \\right\\|' },
          { label: 'Ngoặc góc', preview: '\\langle \\square \\rangle', insert: '\\left\\langle #? \\right\\rangle' },
          { label: 'Phần nguyên dưới', preview: '\\lfloor \\square \\rfloor', insert: '\\left\\lfloor #? \\right\\rfloor' },
          { label: 'Phần nguyên trên', preview: '\\lceil \\square \\rceil', insert: '\\left\\lceil #? \\right\\rceil' },
          { label: 'Hệ 2 phương trình', preview: '\\begin{cases} \\square \\\\ \\square \\end{cases}', insert: '\\begin{cases} #? \\\\ #? \\end{cases}' },
          { label: 'Hệ 3 phương trình', preview: '\\begin{cases} \\square \\\\ \\square \\\\ \\square \\end{cases}', insert: '\\begin{cases} #? \\\\ #? \\\\ #? \\end{cases}' },
          { label: 'Tổ hợp nhị thức', preview: '\\binom{\\square}{\\square}', insert: '\\binom{#?}{#?}' }
        ]
      }
    ]
  },
  {
    id: 'function',
    title: 'Function',
    viTitle: 'Hàm số',
    icon: '\\sin\\square',
    sections: [
      {
        name: 'Hàm lượng giác, Ngược & Hyperbolic',
        items: [
          { label: 'Sine', preview: '\\sin \\square', insert: '\\sin(#?)' },
          { label: 'Cosine', preview: '\\cos \\square', insert: '\\cos(#?)' },
          { label: 'Tangent', preview: '\\tan \\square', insert: '\\tan(#?)' },
          { label: 'Cotangent', preview: '\\cot \\square', insert: '\\cot(#?)' },
          { label: 'Secant', preview: '\\sec \\square', insert: '\\sec(#?)' },
          { label: 'Cosecant', preview: '\\csc \\square', insert: '\\csc(#?)' },
          { label: 'Arcsin', preview: '\\sin^{-1} \\square', insert: '\\sin^{-1}(#?)' },
          { label: 'Arccos', preview: '\\cos^{-1} \\square', insert: '\\cos^{-1}(#?)' },
          { label: 'Arctan', preview: '\\tan^{-1} \\square', insert: '\\tan^{-1}(#?)' },
          { label: 'Sinh', preview: '\\sinh \\square', insert: '\\sinh(#?)' },
          { label: 'Cosh', preview: '\\cosh \\square', insert: '\\cosh(#?)' },
          { label: 'Tanh', preview: '\\tanh \\square', insert: '\\tanh(#?)' }
        ]
      }
    ]
  },
  {
    id: 'accent',
    title: 'Accent',
    viTitle: 'Dấu phụ',
    icon: '\\hat{\\square}',
    alignRight: true,
    sections: [
      {
        name: 'Dấu trên ký tự, Véc-tơ & Ngoặc ôm (Accents & Bars)',
        items: [
          { label: 'Gạch ngang ngắn (Bar)', preview: '\\bar{\\square}', insert: '\\bar{#?}' },
          { label: 'Gạch ngang dài', preview: '\\overline{\\square}', insert: '\\overline{#?}' },
          { label: 'Dấu mũ (Hat)', preview: '\\hat{\\square}', insert: '\\hat{#?}' },
          { label: 'Dấu mũ rộng', preview: '\\widehat{\\square}', insert: '\\widehat{#?}' },
          { label: 'Dấu ngã (Tilde)', preview: '\\tilde{\\square}', insert: '\\tilde{#?}' },
          { label: 'Dấu chấm (Đạo hàm)', preview: '\\dot{\\square}', insert: '\\dot{#?}' },
          { label: 'Hai chấm', preview: '\\ddot{\\square}', insert: '\\ddot{#?}' },
          { label: 'Véc-tơ ngắn', preview: '\\vec{\\square}', insert: '\\vec{#?}' },
          { label: 'Véc-tơ dài', preview: '\\overrightarrow{\\square}', insert: '\\overrightarrow{#?}' },
          { label: 'Ngoặc ôm trên', preview: '\\overbrace{\\square}^{\\square}', insert: '\\overbrace{#?}^{#?}' },
          { label: 'Ngoặc ôm dưới', preview: '\\underbrace{\\square}_{\\square}', insert: '\\underbrace{#?}_{#?}' }
        ]
      }
    ]
  },
  {
    id: 'limitlog',
    title: 'Limit and Log',
    viTitle: 'Giới hạn & Log',
    icon: '\\lim_{\\square\\to\\square}',
    alignRight: true,
    sections: [
      {
        name: 'Giới hạn, Logarit, Cực trị (Limits & Logs)',
        items: [
          { label: 'Giới hạn (Limit)', preview: '\\lim_{\\square \\to \\square} \\square', insert: '\\lim_{#? \\to #?} #?' },
          { label: 'Giới hạn vô cực', preview: '\\lim_{x \\to \\infty} \\square', insert: '\\lim_{x \\to \\infty} #?' },
          { label: 'Logarit cơ số a', preview: '\\log_{\\square} \\square', insert: '\\log_{#?}(#?)' },
          { label: 'Logarit thập phân', preview: '\\log \\square', insert: '\\log(#?)' },
          { label: 'Logarit tự nhiên', preview: '\\ln \\square', insert: '\\ln(#?)' },
          { label: 'Giá trị nhỏ nhất', preview: '\\min_{\\square} \\square', insert: '\\min_{#?}(#?)' },
          { label: 'Giá trị lớn nhất', preview: '\\max_{\\square} \\square', insert: '\\max_{#?}(#?)' }
        ]
      }
    ]
  },
  {
    id: 'operator',
    title: 'Operator',
    viTitle: 'Toán tử',
    icon: '\\xrightarrow{\\square}',
    alignRight: true,
    sections: [
      {
        name: 'Mũi tên có chú thích & Quan hệ đặc biệt',
        items: [
          { label: 'Mũi tên phải có chữ', preview: '\\xrightarrow{\\square}', insert: '\\xrightarrow{#?}' },
          { label: 'Mũi tên trái có chữ', preview: '\\xleftarrow{\\square}', insert: '\\xleftarrow{#?}' },
          { label: 'Dấu bằng có chữ', preview: '\\overset{\\square}{=}', insert: '\\overset{#?}{=}' },
          { label: 'Định nghĩa (:=)', preview: ':=', insert: ':=' },
          { label: 'Định nghĩa (def)', preview: '\\overset{\\text{def}}{=}', insert: '\\overset{\\text{def}}{=}' }
        ]
      }
    ]
  },
  {
    id: 'matrix',
    title: 'Matrix',
    viTitle: 'Ma trận',
    icon: '\\begin{bmatrix}\\square&\\square\\\\\\square&\\square\\end{bmatrix}',
    alignRight: true,
    hasCustomMatrix: true,
    sections: [
      {
        name: 'Ma trận ngoặc vuông, ngoặc tròn & Định thức',
        items: [
          { label: 'Ma trận [2x2]', preview: '\\begin{bmatrix}\\square&\\square\\\\\\square&\\square\\end{bmatrix}', insert: '\\begin{bmatrix}#?&#?\\\\#?&#?\\end{bmatrix}' },
          { label: 'Ma trận [3x3]', preview: '\\begin{bmatrix}\\square&\\square&\\square\\\\\\square&\\square&\\square\\\\\\square&\\square&\\square\\end{bmatrix}', insert: '\\begin{bmatrix}#?&#?&#?\\\\#?&#?&#?\\\\#?&#?&#?\\end{bmatrix}' },
          { label: 'Ma trận (2x2)', preview: '\\begin{pmatrix}\\square&\\square\\\\\\square&\\square\\end{pmatrix}', insert: '\\begin{pmatrix}#?&#?\\\\#?&#?\\end{pmatrix}' },
          { label: 'Định thức |2x2|', preview: '\\begin{vmatrix}\\square&\\square\\\\\\square&\\square\\end{vmatrix}', insert: '\\begin{vmatrix}#?&#?\\\\#?&#?\\end{vmatrix}' },
          { label: 'Véc-tơ cột [2x1]', preview: '\\begin{bmatrix}\\square\\\\\\square\\end{bmatrix}', insert: '\\begin{bmatrix}#?\\\\#?\\end{bmatrix}' },
          { label: 'Véc-tơ hàng [1x3]', preview: '\\begin{bmatrix}\\square&\\square&\\square\\end{bmatrix}', insert: '\\begin{bmatrix}#?&#?&#?\\end{bmatrix}' }
        ]
      }
    ]
  }
];

export interface WordEquationRibbonProps {
  onInsertLaTeX?: (latex: string) => void;
  onSendToAI?: (latex: string) => void;
  initialLaTeX?: string;
  fieldId?: string;
  compact?: boolean;
  showSendButton?: boolean;
  title?: string;
}

export const WordEquationRibbon: React.FC<WordEquationRibbonProps> = ({
  onInsertLaTeX,
  onSendToAI,
  initialLaTeX = '',
  fieldId = 'word-math-field',
  compact = false,
  showSendButton = true,
  title = 'Microsoft Word Equation Toolbar — Web Component'
}) => {
  const [currentMode, setCurrentMode] = useState<'professional' | 'linear'>('professional');
  const [selectedSymbolCategory, setSelectedSymbolCategory] = useState<string>('basic');
  const [openDropdownId, setOpenDropdownId] = useState<string | null>(null);
  const [latexValue, setLatexValue] = useState<string>(
    initialLaTeX || 'f(x) = \\frac{1}{\\sigma\\sqrt{2\\pi}} e^{-\\frac{1}{2}\\left(\\frac{x-\\mu}{\\sigma}\\right)^2}'
  );
  const [matrixRows, setMatrixRows] = useState<number>(3);
  const [matrixCols, setMatrixCols] = useState<number>(3);

  const mathFieldRef = useRef<any>(null);
  const linearInputRef = useRef<HTMLTextAreaElement>(null);

  // Helper to safely render KaTeX HTML
  const renderKatexHTML = (latexStr: string, displayMode: boolean = false) => {
    try {
      if (typeof window !== 'undefined' && window.katex) {
        return window.katex.renderToString(latexStr, {
          throwOnError: false,
          displayMode
        });
      }
    } catch (e) {
      // Fallback
    }
    return `<span style="font-family: math, serif;">${latexStr}</span>`;
  };

  // Sync initialLaTeX if provided from parent
  useEffect(() => {
    if (initialLaTeX && initialLaTeX !== latexValue) {
      setLatexValue(initialLaTeX);
      if (mathFieldRef.current) {
        mathFieldRef.current.value = initialLaTeX;
      }
    }
  }, [initialLaTeX]);

  // Handle click outside to close dropdowns
  useEffect(() => {
    const handleGlobalClick = () => {
      setOpenDropdownId(null);
    };
    document.addEventListener('click', handleGlobalClick);
    return () => document.removeEventListener('click', handleGlobalClick);
  }, []);

  // Sync mathField listener
  useEffect(() => {
    const mf = mathFieldRef.current;
    if (!mf) return;

    const handleInput = () => {
      const val = mf.value || '';
      setLatexValue(val);
      if (onInsertLaTeX) onInsertLaTeX(val);
    };

    mf.addEventListener('input', handleInput);
    return () => mf.removeEventListener('input', handleInput);
  }, [onInsertLaTeX]);

  // Insert Template with #? placeholders
  const insertTemplate = (latexTemplate: string) => {
    const mf = mathFieldRef.current || document.getElementById(fieldId);
    if (currentMode === 'professional' && mf) {
      if (mf.executeCommand) {
        mf.executeCommand([
          'insert',
          latexTemplate,
          {
            focus: true,
            feedback: true,
            selectionMode: 'placeholder'
          }
        ]);
      } else {
        mf.value = (mf.value || '') + latexTemplate.replace(/#\?/g, '');
      }
      if (mf.focus) mf.focus();
      const val = mf.value || '';
      setLatexValue(val);
      if (onInsertLaTeX) onInsertLaTeX(val);
    } else {
      const clean = latexTemplate.replace(/#\?/g, '{}');
      const newVal = (latexValue || '') + ' ' + clean;
      setLatexValue(newVal);
      if (mf) mf.value = newVal;
      if (onInsertLaTeX) onInsertLaTeX(newVal);
      if (linearInputRef.current) linearInputRef.current.focus();
    }
  };

  // Custom matrix generator
  const insertCustomMatrix = () => {
    const rows = Math.min(8, Math.max(1, matrixRows || 2));
    const cols = Math.min(8, Math.max(1, matrixCols || 2));
    const rowStr = Array(cols).fill('#?').join(' & ');
    const fullBody = Array(rows).fill(rowStr).join(' \\\\ ');
    insertTemplate(`\\begin{bmatrix} ${fullBody} \\end{bmatrix}`);
    setOpenDropdownId(null);
  };

  // Switch between Professional (WYSIWYG) and Linear (LaTeX code)
  const setMode = (mode: 'professional' | 'linear') => {
    setCurrentMode(mode);
    const mf = mathFieldRef.current || document.getElementById(fieldId);
    if (mode === 'linear') {
      if (linearInputRef.current) {
        linearInputRef.current.value = latexValue;
        linearInputRef.current.focus();
      }
    } else {
      if (mf) {
        mf.value = latexValue;
        if (mf.focus) mf.focus();
      }
    }
  };

  const syncFromLinear = (val: string) => {
    setLatexValue(val);
    const mf = mathFieldRef.current || document.getElementById(fieldId);
    if (mf) mf.value = val;
    if (onInsertLaTeX) onInsertLaTeX(val);
  };

  const clearEquation = () => {
    setLatexValue('');
    const mf = mathFieldRef.current || document.getElementById(fieldId);
    if (mf) mf.value = '';
    if (linearInputRef.current) linearInputRef.current.value = '';
    if (onInsertLaTeX) onInsertLaTeX('');
    if (mf && mf.focus) mf.focus();
  };

  const handleSendToAI = () => {
    const finalVal = latexValue.trim();
    if (onSendToAI) {
      onSendToAI(finalVal);
    }
  };

  return (
    <div className={`word-app-wrapper text-slate-100 bg-slate-950/95 border-2 border-cyan-500/50 rounded-2xl shadow-[0_0_30px_rgba(6,182,212,0.2)] overflow-visible my-3 max-w-full font-sans ${compact ? 'text-xs' : ''}`}>
      {/* Header Bar - High Contrast Cyberpunk Style */}
      <div className="word-header bg-gradient-to-r from-cyan-950 via-slate-900 to-blue-950 border-b border-cyan-500/40 text-white px-4 py-2.5 font-bold text-xs md:text-sm flex justify-between items-center rounded-t-2xl">
        <span className="flex items-center gap-2">
          <span className="bg-cyan-500/20 border border-cyan-400/50 text-cyan-300 px-2 py-0.5 rounded text-xs font-mono font-bold shadow-[0_0_8px_rgba(6,182,212,0.4)]">
            MS Word Equation Ribbon
          </span>
          <span className="text-white font-extrabold text-xs md:text-sm drop-shadow">{title}</span>
        </span>
        <span className="hidden sm:inline text-xs text-amber-300 font-bold bg-amber-950/60 px-2.5 py-0.5 rounded border border-amber-500/40">
          ✨ KaTeX + MathLive WYSIWYG
        </span>
      </div>

      {/* THANH RIBBON EQUATION CHUẨN MS WORD */}
      <div className="word-ribbon flex flex-wrap items-stretch gap-2 bg-[#080d1a] border-b border-cyan-500/30 p-2.5 text-xs overflow-visible relative">
        {/* NHÓM 1: TOOLS & CONVERSIONS */}
        <div className="ribbon-group flex flex-col justify-between pr-2 border-r border-slate-800">
          <div className="group-content flex items-center gap-1.5 h-full">
            <div className="tool-stack flex flex-col gap-1">
              <button
                type="button"
                className={`tool-btn flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-lg border font-bold transition-all cursor-pointer ${
                  currentMode === 'professional'
                    ? 'bg-cyan-500 border-cyan-300 text-slate-950 font-black shadow-[0_0_12px_rgba(6,182,212,0.5)]'
                    : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-cyan-950 hover:text-cyan-300 hover:border-cyan-500/50'
                }`}
                onClick={() => setMode('professional')}
              >
                <span>Professional (Trực quan)</span>
              </button>
              <button
                type="button"
                className={`tool-btn flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-lg border font-bold transition-all cursor-pointer ${
                  currentMode === 'linear'
                    ? 'bg-cyan-500 border-cyan-300 text-slate-950 font-black shadow-[0_0_12px_rgba(6,182,212,0.5)]'
                    : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-cyan-950 hover:text-cyan-300 hover:border-cyan-500/50'
                }`}
                onClick={() => setMode('linear')}
              >
                <span>Linear (Mã LaTeX)</span>
              </button>
            </div>
            <div className="tool-stack flex flex-col gap-1">
              <button
                type="button"
                className="tool-btn flex items-center gap-1 px-2.5 py-1 text-xs bg-slate-900 border border-slate-700 rounded-lg text-amber-300 font-bold hover:bg-amber-950 hover:border-amber-400 cursor-pointer"
                onClick={() => insertTemplate('\\text{#?}')}
              >
                <b className="text-amber-400">ab</b> <span>Chèn chữ (Text)</span>
              </button>
              <button
                type="button"
                className="tool-btn flex items-center gap-1 px-2.5 py-1 text-xs bg-slate-900 border border-slate-700 rounded-lg text-rose-400 font-bold hover:bg-rose-950 hover:border-rose-400 cursor-pointer"
                onClick={clearEquation}
              >
                <span>Xóa toàn bộ</span>
              </button>
            </div>
          </div>
          <div className="group-title text-center text-[10px] font-black text-cyan-400/80 mt-1 uppercase tracking-wider">
            Conversions
          </div>
        </div>

        {/* NHÓM 2: SYMBOLS GALLERY (8 DANH MỤC CỦA WORD) */}
        <div className="ribbon-group flex flex-col justify-between pr-2 border-r border-slate-800">
          <div className="group-content flex items-center gap-1 h-full">
            <div className="symbols-box w-[260px] md:w-[280px] bg-slate-900 border border-cyan-500/40 rounded-xl p-1.5">
              <select
                className="symbols-category-select w-full text-xs p-1 mb-1 border border-cyan-500/40 rounded-lg bg-slate-950 font-bold text-cyan-300 focus:outline-none"
                value={selectedSymbolCategory}
                onChange={(e) => setSelectedSymbolCategory(e.target.value)}
              >
                <option value="basic">1. Toán cơ bản (Basic Math)</option>
                <option value="greek">2. Chữ cái Hy Lạp (Greek Letters)</option>
                <option value="letterlike">3. Ký hiệu giống chữ (Letter-Like)</option>
                <option value="operators">4. Toán tử (Operators)</option>
                <option value="arrows">5. Mũi tên (Arrows)</option>
                <option value="negated">6. Quan hệ phủ định (Negated)</option>
                <option value="scripts">7. Tập hợp & Chữ kiểu (Scripts)</option>
                <option value="geometry">8. Hình học (Geometry)</option>
              </select>
              <div className="symbols-grid grid grid-cols-9 gap-1 h-[56px] overflow-y-auto pr-1">
                {(WORD_SYMBOLS[selectedSymbolCategory] || []).map((sym, idx) => (
                  <button
                    key={idx}
                    type="button"
                    className="sym-btn h-[26px] bg-slate-950 border border-slate-800 hover:border-cyan-400 hover:bg-cyan-950 rounded flex items-center justify-center text-cyan-200 hover:text-white transition-all cursor-pointer text-xs p-0 font-bold"
                    title={`Chèn ${sym}`}
                    onClick={() => insertTemplate(sym)}
                    dangerouslySetInnerHTML={{ __html: renderKatexHTML(sym) }}
                  />
                ))}
              </div>
            </div>
          </div>
          <div className="group-title text-center text-[10px] font-black text-cyan-400/80 mt-1 uppercase tracking-wider">
            Symbols
          </div>
        </div>

        {/* NHÓM 3: STRUCTURES (11 MENU THẢ XUỐNG CỦA WORD) */}
        <div className="ribbon-group flex flex-col justify-between pr-0 border-r-0 max-w-full overflow-visible">
          <div className="group-content flex items-center gap-1 h-full">
            <div className="structures-list flex gap-1 flex-wrap">
              {WORD_STRUCTURES.map((struct) => {
                const isOpen = openDropdownId === struct.id;
                return (
                  <div key={struct.id} className="struct-dropdown relative">
                    <button
                      type="button"
                      className={`struct-trigger w-[58px] h-[72px] p-1 flex flex-col items-center justify-between rounded-xl border transition-all cursor-pointer ${
                        isOpen
                          ? 'bg-cyan-950 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.4)]'
                          : 'bg-slate-900 border-slate-800 hover:bg-slate-800 hover:border-cyan-500/50'
                      }`}
                      onClick={(e) => {
                        e.stopPropagation();
                        setOpenDropdownId(isOpen ? null : struct.id);
                      }}
                    >
                      <div
                        className="struct-icon h-[34px] flex items-center justify-center text-cyan-300 text-sm font-bold"
                        dangerouslySetInnerHTML={{ __html: renderKatexHTML(struct.icon) }}
                      />
                      <div className="struct-label text-[11px] font-bold text-slate-200 text-center leading-tight">
                        {struct.viTitle}
                      </div>
                      <div className="struct-caret text-[8px] text-cyan-400">▼</div>
                    </button>

                    {/* Menu thả xuống - Khay rộng 520px Không Cuộn */}
                    {isOpen && (
                      <div
                        className={`dropdown-menu absolute top-[calc(100%+4px)] z-[9999] bg-slate-950 border-2 border-cyan-500/60 rounded-2xl shadow-[0_0_35px_rgba(6,182,212,0.35)] w-[520px] max-w-[90vw] p-3 text-white overflow-visible ${
                          struct.alignRight ? 'right-0' : 'left-0'
                        }`}
                        onClick={(e) => e.stopPropagation()}
                      >
                        {struct.sections.map((sec, secIdx) => (
                          <div key={secIdx}>
                            <div className="menu-section-title text-xs font-black text-amber-300 bg-slate-900 px-2.5 py-1 my-1.5 -mx-3 border-y border-slate-800">
                              {sec.name}
                            </div>
                            <div className="template-grid grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-1.5 mb-2">
                              {sec.items.map((item, itemIdx) => (
                                <button
                                  key={itemIdx}
                                  type="button"
                                  className="template-card flex flex-col items-center justify-center min-h-[66px] p-2 bg-slate-900 border border-slate-800 hover:border-cyan-400 hover:bg-cyan-950/80 rounded-xl transition-all cursor-pointer group"
                                  onClick={() => {
                                    insertTemplate(item.insert);
                                    setOpenDropdownId(null);
                                  }}
                                >
                                  <div
                                    className="template-preview text-base mb-1 text-cyan-300 group-hover:text-white"
                                    dangerouslySetInnerHTML={{ __html: renderKatexHTML(item.preview, true) }}
                                  />
                                  <div className="template-name text-[10.5px] font-bold text-slate-200 text-center leading-tight">
                                    {item.label}
                                  </div>
                                </button>
                              ))}
                            </div>
                          </div>
                        ))}

                        {/* Ma trận tùy chỉnh */}
                        {struct.hasCustomMatrix && (
                          <div className="custom-matrix-box bg-slate-900 p-2.5 rounded-xl border border-cyan-500/40 mt-2 flex items-center justify-between gap-1.5 text-xs font-bold">
                            <span className="text-cyan-300">Tùy chỉnh Ma trận (m × n):</span>
                            <div className="flex items-center gap-1">
                              <input
                                type="number"
                                className="w-12 p-1 text-center bg-slate-950 border border-cyan-500/40 rounded-lg text-xs font-bold text-white"
                                value={matrixRows}
                                min={1}
                                max={8}
                                onChange={(e) => setMatrixRows(parseInt(e.target.value) || 2)}
                                title="Số hàng"
                              />
                              <span className="text-slate-400">×</span>
                              <input
                                type="number"
                                className="w-12 p-1 text-center bg-slate-950 border border-cyan-500/40 rounded-lg text-xs font-bold text-white"
                                value={matrixCols}
                                min={1}
                                max={8}
                                onChange={(e) => setMatrixCols(parseInt(e.target.value) || 2)}
                                title="Số cột"
                              />
                            </div>
                            <button
                              type="button"
                              className="bg-cyan-500 text-slate-950 hover:bg-cyan-400 px-3 py-1 rounded-lg text-xs font-black transition-all cursor-pointer shadow-[0_0_10px_rgba(6,182,212,0.4)]"
                              onClick={insertCustomMatrix}
                            >
                              Chèn Ma trận
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
          <div className="group-title text-center text-[10px] font-black text-cyan-400/80 mt-1 uppercase tracking-wider">
            Structures
          </div>
        </div>
      </div>

      {/* VÙNG SOẠN THẢO PHƯƠNG TRÌNH */}
      <div className="word-document-area p-4 bg-slate-950">
        <div className="equation-box-label text-xs font-bold text-slate-300 mb-2 flex flex-wrap justify-between items-center gap-2">
          <span>
            Bấm nút biểu tượng trên Ribbon, click trực tiếp vào ô vuông <span className="font-mono text-cyan-400 font-bold">$\square$</span> hoặc nhấn phím <b className="text-amber-300 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-700">Tab</b> để di chuyển nhập số:
          </span>
          <span className="bg-cyan-950 text-cyan-300 border border-cyan-500/40 font-bold px-2.5 py-1 rounded-lg text-xs">
            Chế độ: {currentMode === 'professional' ? 'Professional (Trực quan)' : 'Linear (Mã LaTeX)'}
          </span>
        </div>

        {/* Ô nhập WYSIWYG Web Component MathLive */}
        <div className={currentMode === 'professional' ? 'block' : 'hidden'}>
          <math-field
            id={fieldId}
            ref={mathFieldRef}
            virtual-keyboard-mode="manual"
            keypress-sound="none"
            smart-fence="true"
            smart-frac="true"
            smart-exponent="true"
            style={{
              width: '100%',
              minHeight: '88px',
              fontSize: '24px',
              padding: '14px 18px',
              backgroundColor: '#030712',
              color: '#22d3ee',
              border: '2px solid #06b6d4',
              borderRadius: '12px',
              boxShadow: '0 0 20px rgba(6, 182, 212, 0.25)',
            }}
          >
            {latexValue}
          </math-field>
        </div>

        {/* Ô nhập Linear (LaTeX code) */}
        <div className={currentMode === 'linear' ? 'block' : 'hidden'}>
          <textarea
            ref={linearInputRef}
            className="w-full min-h-[88px] font-mono text-sm p-3.5 border-2 border-cyan-500/50 rounded-xl focus:outline-none bg-slate-950 text-cyan-200 placeholder-slate-500 font-bold"
            value={latexValue}
            onChange={(e) => syncFromLinear(e.target.value)}
            placeholder="Nhập mã LaTeX trực tiếp tại đây..."
          />
        </div>
      </div>

      {/* THANH GỬI DỮ LIỆU CHO AI */}
      <div className="ai-footer flex flex-wrap justify-between items-center p-3.5 bg-[#080d1a] border-t border-cyan-500/30 rounded-b-2xl gap-2">
        <div className="latex-status font-mono text-xs text-slate-200 bg-slate-900 border border-cyan-500/30 px-3 py-1.5 rounded-lg max-w-full md:max-w-[70%] overflow-x-auto whitespace-nowrap font-bold">
          LaTeX Output: <span className="text-cyan-300 font-extrabold">{latexValue || '(Rỗng)'}</span>
        </div>
        {showSendButton && (
          <button
            type="button"
            className="ai-submit-btn bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black px-6 py-2.5 rounded-xl text-xs md:text-sm flex items-center gap-1.5 shadow-[0_0_15px_rgba(6,182,212,0.4)] transition-all cursor-pointer ml-auto"
            onClick={handleSendToAI}
          >
            <span>✨ Gửi công thức vào AI</span>
          </button>
        )}
      </div>
    </div>
  );
};
