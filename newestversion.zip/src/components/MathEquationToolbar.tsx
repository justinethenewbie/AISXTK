import React, { useState, useMemo } from 'react';
import { MathFormula } from './MathFormula';
import { WordEquationRibbon } from './WordEquationRibbon';
import {
  Sigma,
  Search,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

export interface EquationItem {
  id: string;
  label: string;
  formula: string;
  insertText: string;
  category: string;
}

export const EQUATION_CATEGORIES = [
  { id: 'common', name: '⭐ Phổ Biến', icon: '⭐' },
  { id: 'fractions', name: '➗ Phân Số & Căn', icon: '➗' },
  { id: 'integrals', name: '📐 Tích Phân & Tổng', icon: '📐' },
  { id: 'probability', name: '🎲 Xác Suất & Biến Cố', icon: '🎲' },
  { id: 'greek', name: '🔤 Ký Tự Hy Lạp', icon: '🔤' },
  { id: 'symbols', name: '⋯ Ký Hiệu & Ba Chấm', icon: '⋯' },
  { id: 'stats', name: '📊 Thống Kê & Kiểm Định', icon: '📊' },
];

export const EQUATION_DATA: EquationItem[] = [
  // 1. Phổ Biến (Common)
  { id: 'com-1', label: 'Phân số đơn', formula: '\\frac{a}{b}', insertText: '\\frac{a}{b}', category: 'common' },
  { id: 'com-2', label: 'Căn bậc hai', formula: '\\sqrt{x}', insertText: '\\sqrt{x}', category: 'common' },
  { id: 'com-3', label: 'Sai số tỷ lệ', formula: '\\epsilon = 1.96 \\cdot \\sqrt{\\frac{p(1-p)}{n}}', insertText: '\\epsilon = 1.96 \\cdot \\sqrt{\\frac{p(1-p)}{n}}', category: 'common' },
  { id: 'com-4', label: 'Z-score chuẩn', formula: 'Z = \\frac{\\bar{X} - \\mu}{\\sigma / \\sqrt{n}}', insertText: 'Z = \\frac{\\bar{X} - \\mu}{\\sigma / \\sqrt{n}}', category: 'common' },
  { id: 'com-5', label: 't-Student', formula: 't = \\frac{\\bar{X} - \\mu}{s / \\sqrt{n}}', insertText: 't = \\frac{\\bar{X} - \\mu}{s / \\sqrt{n}}', category: 'common' },
  { id: 'com-6', label: 'Dấu ba chấm', formula: '\\dots', insertText: '\\dots', category: 'common' },
  { id: 'com-7', label: 'Dãy biến mẫu', formula: 'X_1, X_2, \\dots, X_n', insertText: 'X_1, X_2, \\dots, X_n', category: 'common' },
  { id: 'com-8', label: 'Định lý Bayes', formula: 'P(A|B) = \\frac{P(A) \\cdot P(B|A)}{P(B)}', insertText: 'P(A|B) = \\frac{P(A) \\cdot P(B|A)}{P(B)}', category: 'common' },
  { id: 'com-9', label: 'Phương sai s^2', formula: 's^2', insertText: 's^2', category: 'common' },
  { id: 'com-10', label: 'Khi bình phương', formula: '\\chi^2', insertText: '\\chi^2', category: 'common' },

  // 2. Phân Số & Căn (Fractions & Radicals)
  { id: 'frac-1', label: 'Phân số a/b', formula: '\\frac{a}{b}', insertText: '\\frac{a}{b}', category: 'fractions' },
  { id: 'frac-2', label: 'Đạo hàm df/dx', formula: '\\frac{df}{dx}', insertText: '\\frac{df}{dx}', category: 'fractions' },
  { id: 'frac-3', label: 'Xác suất cổ điển', formula: '\\frac{n_A}{n_\\Omega}', insertText: '\\frac{n_A}{n_\\Omega}', category: 'fractions' },
  { id: 'frac-4', label: 'Căn bậc hai', formula: '\\sqrt{x}', insertText: '\\sqrt{x}', category: 'fractions' },
  { id: 'frac-5', label: 'Căn bậc n', formula: '\\sqrt[n]{x}', insertText: '\\sqrt[n]{x}', category: 'fractions' },
  { id: 'frac-6', label: 'Căn sai số tỷ lệ', formula: '\\sqrt{\\frac{p(1-p)}{n}}', insertText: '\\sqrt{\\frac{p(1-p)}{n}}', category: 'fractions' },
  { id: 'frac-7', label: 'Sai số chuẩn sigma', formula: '\\frac{\\sigma}{\\sqrt{n}}', insertText: '\\frac{\\sigma}{\\sqrt{n}}', category: 'fractions' },
  { id: 'frac-8', label: 'Sai số chuẩn s', formula: '\\frac{s}{\\sqrt{n}}', insertText: '\\frac{s}{\\sqrt{n}}', category: 'fractions' },

  // 3. Tích Phân & Tổng (Integrals & Summations)
  { id: 'int-1', label: 'Tích phân cận a->b', formula: '\\int_{a}^{b} f(x) \, dx', insertText: '\\int_{a}^{b} f(x) \, dx', category: 'integrals' },
  { id: 'int-2', label: 'Chuẩn hóa hàm mật độ', formula: '\\int_{-\\infty}^{+\\infty} f(x) \, dx = 1', insertText: '\\int_{-\\infty}^{+\\infty} f(x) \, dx = 1', category: 'integrals' },
  { id: 'int-3', label: 'Hàm tích lũy F(x)', formula: 'F(x) = \\int_{-\\infty}^{x} f(t) \, dt', insertText: 'F(x) = \\int_{-\\infty}^{x} f(t) \, dt', category: 'integrals' },
  { id: 'int-4', label: 'Tổng xích-ma mẫu', formula: '\\sum_{i=1}^{n} x_i', insertText: '\\sum_{i=1}^{n} x_i', category: 'integrals' },
  { id: 'int-5', label: 'Kỳ vọng E(X)', formula: 'E(X) = \\sum_{i=1}^{n} x_i \\cdot p_i', insertText: 'E(X) = \\sum_{i=1}^{n} x_i \\cdot p_i', category: 'integrals' },
  { id: 'int-6', label: 'Tổng xác suất', formula: '\\sum P(X=x) = 1', insertText: '\\sum P(X=x) = 1', category: 'integrals' },

  // 4. Xác Suất & Biến Cố (Probability & Events)
  { id: 'prob-1', label: 'Xác suất P(A)', formula: 'P(A)', insertText: 'P(A)', category: 'probability' },
  { id: 'prob-2', label: 'Xác suất P(B)', formula: 'P(B)', insertText: 'P(B)', category: 'probability' },
  { id: 'prob-3', label: 'Biến cố đối', formula: 'P(\\bar{A}) = 1 - P(A)', insertText: 'P(\\bar{A}) = 1 - P(A)', category: 'probability' },
  { id: 'prob-4', label: 'Giao biến cố', formula: 'P(A \\cap B)', insertText: 'P(A \\cap B)', category: 'probability' },
  { id: 'prob-5', label: 'Hợp biến cố', formula: 'P(A \\cup B)', insertText: 'P(A \\cup B)', category: 'probability' },
  { id: 'prob-6', label: 'Xác suất điều kiện', formula: 'P(A|B)', insertText: 'P(A|B)', category: 'probability' },
  { id: 'prob-7', label: 'Kỳ vọng E(X)', formula: 'E(X)', insertText: 'E(X)', category: 'probability' },
  { id: 'prob-8', label: 'Phương sai Var(X)', formula: 'Var(X)', insertText: 'Var(X)', category: 'probability' },
  { id: 'prob-9', label: 'Độ lệch chuẩn', formula: '\\sigma(X)', insertText: '\\sigma(X)', category: 'probability' },
  { id: 'prob-10', label: 'Tổ hợp C_n^k', formula: 'C_n^k', insertText: 'C_n^k', category: 'probability' },
  { id: 'prob-11', label: 'Chỉnh hợp A_n^k', formula: 'A_n^k', insertText: 'A_n^k', category: 'probability' },
  { id: 'prob-12', label: 'Giai thừa n!', formula: 'n!', insertText: 'n!', category: 'probability' },
  { id: 'prob-13', label: 'Công thức Bernoulli', formula: 'P_n(k) = C_n^k p^k (1-p)^{n-k}', insertText: 'P_n(k) = C_n^k p^k (1-p)^{n-k}', category: 'probability' },
  { id: 'prob-14', label: 'Phân phối Poisson', formula: 'P(X=k) = \\frac{\\lambda^k e^{-\\lambda}}{k!}', insertText: 'P(X=k) = \\frac{\\lambda^k e^{-\\lambda}}{k!}', category: 'probability' },
  { id: 'prob-15', label: 'Phân phối Chuẩn', formula: 'X \\sim N(\\mu, \\sigma^2)', insertText: 'X \\sim N(\\mu, \\sigma^2)', category: 'probability' },
  { id: 'prob-16', label: 'Chuẩn tắc Z', formula: 'Z \\sim N(0, 1)', insertText: 'Z \\sim N(0, 1)', category: 'probability' },
  { id: 'prob-17', label: 'Tích lũy chuẩn Phi', formula: '\\Phi(z)', insertText: '\\Phi(z)', category: 'probability' },

  // 5. Ký Tự Hy Lạp (Greek Letters)
  { id: 'grk-1', label: 'Epsilon', formula: '\\epsilon', insertText: '\\epsilon', category: 'greek' },
  { id: 'grk-2', label: 'Mu (Trung bình)', formula: '\\mu', insertText: '\\mu', category: 'greek' },
  { id: 'grk-3', label: 'Sigma', formula: '\\sigma', insertText: '\\sigma', category: 'greek' },
  { id: 'grk-4', label: 'Sigma bình', formula: '\\sigma^2', insertText: '\\sigma^2', category: 'greek' },
  { id: 'grk-5', label: 'Alpha', formula: '\\alpha', insertText: '\\alpha', category: 'greek' },
  { id: 'grk-6', label: 'Beta', formula: '\\beta', insertText: '\\beta', category: 'greek' },
  { id: 'grk-7', label: 'Độ tin cậy 1-alpha', formula: '1-\\alpha', insertText: '1-\\alpha', category: 'greek' },
  { id: 'grk-8', label: 'Lambda', formula: '\\lambda', insertText: '\\lambda', category: 'greek' },
  { id: 'grk-9', label: 'Theta', formula: '\\theta', insertText: '\\theta', category: 'greek' },
  { id: 'grk-10', label: 'Phi hoa', formula: '\\Phi', insertText: '\\Phi', category: 'greek' },
  { id: 'grk-11', label: 'Phi thường', formula: '\\phi', insertText: '\\phi', category: 'greek' },
  { id: 'grk-12', label: 'Chi-square', formula: '\\chi^2', insertText: '\\chi^2', category: 'greek' },
  { id: 'grk-13', label: 'Pi', formula: '\\pi', insertText: '\\pi', category: 'greek' },
  { id: 'grk-14', label: 'Delta', formula: '\\Delta', insertText: '\\Delta', category: 'greek' },
  { id: 'grk-15', label: 'Omega', formula: '\\Omega', insertText: '\\Omega', category: 'greek' },
  { id: 'grk-16', label: 'Rho', formula: '\\rho', insertText: '\\rho', category: 'greek' },

  // 6. Ký Hiệu & Dấu Ba Chấm (Symbols & Ellipsis)
  { id: 'sym-1', label: 'Ba chấm \\dots', formula: '\\dots', insertText: '\\dots', category: 'symbols' },
  { id: 'sym-2', label: 'Ba chấm ldots', formula: '\\ldots', insertText: '\\ldots', category: 'symbols' },
  { id: 'sym-3', label: 'Ba chấm cdots', formula: '\\cdots', insertText: '\\cdots', category: 'symbols' },
  { id: 'sym-4', label: 'Nhân cdot', formula: '\\cdot', insertText: '\\cdot', category: 'symbols' },
  { id: 'sym-5', label: 'Nhân chéo', formula: '\\times', insertText: '\\times', category: 'symbols' },
  { id: 'sym-6', label: 'Cộng trừ', formula: '\\pm', insertText: '\\pm', category: 'symbols' },
  { id: 'sym-7', label: 'Nhỏ hơn bằng', formula: '\\le', insertText: '\\le', category: 'symbols' },
  { id: 'sym-8', label: 'Lớn hơn bằng', formula: '\\ge', insertText: '\\ge', category: 'symbols' },
  { id: 'sym-9', label: 'Khác', formula: '\\ne', insertText: '\\ne', category: 'symbols' },
  { id: 'sym-10', label: 'Xấp xỉ', formula: '\\approx', insertText: '\\approx', category: 'symbols' },
  { id: 'sym-11', label: 'Phân phối sim', formula: '\\sim', insertText: '\\sim', category: 'symbols' },
  { id: 'sym-12', label: 'Âm vô cực', formula: '-\\infty', insertText: '-\\infty', category: 'symbols' },
  { id: 'sym-13', label: 'Dương vô cực', formula: '+\\infty', insertText: '+\\infty', category: 'symbols' },
  { id: 'sym-14', label: 'Thuộc', formula: '\\in', insertText: '\\in', category: 'symbols' },
  { id: 'sym-15', label: 'Với mọi', formula: '\\forall', insertText: '\\forall', category: 'symbols' },
  { id: 'sym-16', label: 'Tồn tại', formula: '\\exists', insertText: '\\exists', category: 'symbols' },

  // 7. Thống Kê & Kiểm Định (Inference & Hypothesis)
  { id: 'st-1', label: 'Trung bình X_bar', formula: '\\bar{X}', insertText: '\\bar{X}', category: 'stats' },
  { id: 'st-2', label: 'Trung bình x_bar', formula: '\\bar{x}', insertText: '\\bar{x}', category: 'stats' },
  { id: 'st-3', label: 'Tỷ lệ p_hat', formula: '\\hat{p}', insertText: '\\hat{p}', category: 'stats' },
  { id: 'st-4', label: 'Phương sai s^2', formula: 's^2', insertText: 's^2', category: 'stats' },
  { id: 'st-5', label: 'Phương sai S^2', formula: 'S^2', insertText: 'S^2', category: 'stats' },
  { id: 'st-6', label: 'Tới hạn Z_alpha/2', formula: 'Z_{\\alpha/2}', insertText: 'Z_{\\alpha/2}', category: 'stats' },
  { id: 'st-7', label: 'Tới hạn t-Student', formula: 't_{\\alpha/2; n-1}', insertText: 't_{\\alpha/2; n-1}', category: 'stats' },
  { id: 'st-8', label: 'Giả thiết H0', formula: 'H_0: \\mu = \\mu_0', insertText: 'H_0: \\mu = \\mu_0', category: 'stats' },
  { id: 'st-9', label: 'Đối thiết H1', formula: 'H_1: \\mu \\ne \\mu_0', insertText: 'H_1: \\mu \\ne \\mu_0', category: 'stats' },
  { id: 'st-10', label: 'Miền bác bỏ W_alpha', formula: 'W_\\alpha = \\{ |Z| > Z_{\\alpha/2} \\}', insertText: 'W_\\alpha = \\{ |Z| > Z_{\\alpha/2} \\}', category: 'stats' },
  { id: 'st-11', label: 'Khoảng tin cậy', formula: '(\\bar{x} - \\epsilon, \\bar{x} + \\epsilon)', insertText: '(\\bar{x} - \\epsilon, \\bar{x} + \\epsilon)', category: 'stats' },
  { id: 'st-12', label: 'p-value', formula: 'p\\text{-value}', insertText: 'p\\text{-value}', category: 'stats' },
];

interface MathEquationToolbarProps {
  onInsert: (formulaText: string) => void;
  className?: string;
  collapsible?: boolean;
  defaultExpanded?: boolean;
}

export const MathEquationToolbar: React.FC<MathEquationToolbarProps> = ({
  onInsert,
  className = '',
  collapsible = true,
  defaultExpanded = true,
}) => {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);
  const [editorMode, setEditorMode] = useState<'ribbon' | 'grid'>('ribbon');
  const [activeCategory, setActiveCategory] = useState<string>('common');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredEquations = useMemo(() => {
    if (!searchQuery.trim()) {
      return EQUATION_DATA.filter((eq) => eq.category === activeCategory);
    }
    const q = searchQuery.toLowerCase().trim();
    return EQUATION_DATA.filter(
      (eq) =>
        eq.label.toLowerCase().includes(q) ||
        eq.formula.toLowerCase().includes(q) ||
        eq.category.toLowerCase().includes(q)
    );
  }, [activeCategory, searchQuery]);

  return (
    <div
      className={`bg-slate-900 border-2 border-cyan-500/40 rounded-2xl p-3 space-y-2.5 shadow-[0_0_20px_rgba(6,182,212,0.15)] ${className}`}
    >
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
        <div className="flex items-center gap-2 text-cyan-300 font-extrabold text-xs sm:text-sm">
          <div className="p-1.5 bg-cyan-500/20 rounded-lg text-cyan-400">
            <Sigma className="w-4 h-4" />
          </div>
          <span>BẢNG CÔNG THỨC EQUATION CHUẨN MICROSOFT WORD (XSTK)</span>
          <span className="text-[10px] bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 px-2 py-0.5 rounded-full font-black">
            WORD PRO
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* View Mode Toggle */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              type="button"
              onClick={() => setEditorMode('ribbon')}
              className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-colors ${
                editorMode === 'ribbon'
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Ribbon MS Word (WYSIWYG)
            </button>
            <button
              type="button"
              onClick={() => setEditorMode('grid')}
              className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-colors ${
                editorMode === 'grid'
                  ? 'bg-cyan-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Lưới Ký Hiệu Nhanh
            </button>
          </div>

          {collapsible && (
            <button
              type="button"
              onClick={() => setIsExpanded(!isExpanded)}
              className="py-1 px-2.5 bg-slate-950 hover:bg-slate-800 border border-cyan-500/30 text-cyan-300 text-xs font-bold rounded-xl flex items-center gap-1 transition-all cursor-pointer"
            >
              <span>{isExpanded ? 'Thu Gọn' : 'Mở Bảng Equation'}</span>
              {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          )}
        </div>
      </div>

      {isExpanded && (
        <div className="pt-1">
          {editorMode === 'ribbon' ? (
            <WordEquationRibbon
              onInsertLaTeX={(latex) => onInsert(latex)}
              onSendToAI={(latex) => onInsert(latex)}
              compact={true}
              showSendButton={true}
            />
          ) : (
            <div className="space-y-3">
              {/* Search Input & Quick Info */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2">
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-cyan-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Tìm công thức... (gõ 'epsilon', 'can', 'tich phan', 'ba cham', 'bayes'...)"
                    className="w-full pl-8 pr-3 py-1.5 bg-slate-950 border border-cyan-500/30 rounded-xl text-xs text-white placeholder-slate-400 outline-none focus:border-cyan-400 font-medium"
                  />
                </div>
              </div>

              {/* Category Tabs */}
              {!searchQuery && (
                <div className="flex items-center gap-1 overflow-x-auto no-scrollbar pb-1 border-b border-slate-800">
                  {EQUATION_CATEGORIES.map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setActiveCategory(cat.id)}
                      className={`py-1 px-2.5 rounded-xl text-[11px] font-bold whitespace-nowrap transition-all cursor-pointer ${
                        activeCategory === cat.id
                          ? 'bg-gradient-to-r from-cyan-500 to-emerald-500 text-slate-950 shadow-[0_0_10px_rgba(6,182,212,0.4)]'
                          : 'bg-slate-950/80 hover:bg-slate-800 text-slate-300 border border-slate-800'
                      }`}
                    >
                      {cat.name}
                    </button>
                  ))}
                </div>
              )}

              {/* Equations Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2 max-h-56 overflow-y-auto pr-1">
                {filteredEquations.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onInsert(item.insertText)}
                    title={`Chèn: ${item.formula}`}
                    className="p-2 rounded-xl border border-slate-800 hover:border-cyan-400/60 bg-slate-950/90 hover:bg-cyan-950/80 text-slate-200 hover:text-cyan-200 text-center transition-all cursor-pointer flex flex-col items-center justify-between gap-1 group shadow-sm"
                  >
                    <div className="text-xs font-semibold text-slate-400 group-hover:text-cyan-300 truncate w-full">
                      {item.label}
                    </div>
                    <div className="py-1 px-1.5 w-full bg-slate-900/80 rounded-lg overflow-x-auto border border-slate-800/80 group-hover:border-cyan-500/40">
                      <MathFormula math={item.formula} />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
