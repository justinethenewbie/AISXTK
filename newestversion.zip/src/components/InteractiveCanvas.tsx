import React, { useRef, useState, useEffect } from 'react';
import { Pencil, Eraser, Trash2, Bold, Italic, Underline, Sigma, Type, Check, Sparkles } from 'lucide-react';
import { MathEquationToolbar } from './MathEquationToolbar';
import { MathText } from './MathFormula';

interface InteractiveCanvasProps {
  onExportCanvas: (dataUrl: string, textContent: string) => void;
  isSubmitting?: boolean;
  initialText?: string;
}

export const InteractiveCanvas: React.FC<InteractiveCanvasProps> = ({
  onExportCanvas,
  isSubmitting = false,
  initialText = '',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [color, setColor] = useState('#00f0ff');
  const [lineWidth, setLineWidth] = useState(3);
  const [mode, setMode] = useState<'draw' | 'erase' | 'text'>('draw');
  const [typedText, setTypedText] = useState(initialText);

  // Formatting states for text
  const [isBold, setIsBold] = useState(false);
  const [isItalic, setIsItalic] = useState(false);
  const [isUnderline, setIsUnderline] = useState(false);
  const [showEquationToolbar, setShowEquationToolbar] = useState(true);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Fill dark background
    ctx.fillStyle = '#020617';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  }, []);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (mode === 'text') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setIsDrawing(true);
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

    ctx.beginPath();
    ctx.moveTo(clientX - rect.left, clientY - rect.top);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing || mode === 'text') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

    ctx.lineWidth = mode === 'erase' ? 24 : lineWidth;
    ctx.lineCap = 'round';
    ctx.strokeStyle = mode === 'erase' ? '#020617' : color;

    ctx.lineTo(clientX - rect.left, clientY - rect.top);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#020617';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  };

  const insertFormulaText = (formula: string) => {
    const textarea = textareaRef.current;
    if (textarea) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const text = typedText;
      const newText = text.substring(0, start) + ' ' + formula + ' ' + text.substring(end);
      setTypedText(newText);
      setTimeout(() => {
        textarea.focus();
        textarea.setSelectionRange(start + formula.length + 2, start + formula.length + 2);
      }, 50);
    } else {
      setTypedText((prev) => (prev ? prev + ' ' + formula : formula));
    }
  };

  const handleExport = () => {
    const canvas = canvasRef.current;
    const dataUrl = canvas ? canvas.toDataURL('image/png') : '';
    onExportCanvas(dataUrl, typedText);
  };

  return (
    <div className="bg-slate-900 border-2 border-cyan-500/40 rounded-3xl p-4 shadow-xl space-y-4 text-slate-100">
      {/* Equation Toolbar Word Style */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-black text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <Sigma className="w-4 h-4 text-cyan-400" />
              <span>Bảng Công Thức Equation Word Soạn Bài</span>
            </span>
          </div>
          <button
            onClick={() => setShowEquationToolbar(!showEquationToolbar)}
            className="text-[11px] font-bold text-cyan-300 bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-500/30 px-3 py-1 rounded-xl transition-all"
          >
            {showEquationToolbar ? 'Ẩn Bảng Equation' : 'Hiện Bảng Equation Word'}
          </button>
        </div>

        {showEquationToolbar && (
          <MathEquationToolbar onInsert={insertFormulaText} defaultExpanded={true} />
        )}
      </div>

      {/* Drawing & Writing Control Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 bg-slate-950/90 border border-slate-800 rounded-2xl text-xs">
        <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setMode('draw')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 font-bold transition-all cursor-pointer ${
              mode === 'draw'
                ? 'bg-gradient-to-r from-cyan-500 to-emerald-500 text-slate-950 shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
            title="Vẽ tay iPad / Chuột"
          >
            <Pencil className="w-3.5 h-3.5" />
            <span>Viết Tay iPad</span>
          </button>

          <button
            onClick={() => setMode('erase')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 font-bold transition-all cursor-pointer ${
              mode === 'erase'
                ? 'bg-gradient-to-r from-cyan-500 to-emerald-500 text-slate-950 shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
            title="Tẩy nét vẽ"
          >
            <Eraser className="w-3.5 h-3.5" />
            <span>Tẩy Nét</span>
          </button>

          <button
            onClick={() => setMode('text')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 font-bold transition-all cursor-pointer ${
              mode === 'text'
                ? 'bg-gradient-to-r from-cyan-500 to-emerald-500 text-slate-950 shadow-sm'
                : 'text-slate-300 hover:text-white'
            }`}
            title="Soạn thảo văn bản Word"
          >
            <Type className="w-3.5 h-3.5" />
            <span>Gõ Phím Word</span>
          </button>
        </div>

        {/* Word Formatting Controls */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setIsBold(!isBold)}
            className={`p-1.5 rounded-lg ${isBold ? 'bg-cyan-500 text-slate-950 font-black' : 'text-slate-300 hover:text-white'}`}
          >
            <Bold className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setIsItalic(!isItalic)}
            className={`p-1.5 rounded-lg ${isItalic ? 'bg-cyan-500 text-slate-950 font-black' : 'text-slate-300 hover:text-white'}`}
          >
            <Italic className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setIsUnderline(!isUnderline)}
            className={`p-1.5 rounded-lg ${isUnderline ? 'bg-cyan-500 text-slate-950 font-black' : 'text-slate-300 hover:text-white'}`}
          >
            <Underline className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Color Palette */}
        {mode === 'draw' && (
          <div className="flex items-center gap-1.5">
            {['#00f0ff', '#10b981', '#f59e0b', '#ec4899', '#ffffff'].map((c) => (
              <button
                key={c}
                onClick={() => setColor(c)}
                className={`w-5 h-5 rounded-full border-2 transition-transform cursor-pointer ${
                  color === c ? 'scale-125 border-cyan-300 shadow-[0_0_10px_#00f0ff]' : 'border-transparent'
                }`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
        )}

        <button
          onClick={clearCanvas}
          className="py-1.5 px-3 bg-rose-950/60 hover:bg-rose-900 border border-rose-500/40 text-rose-200 rounded-xl flex items-center gap-1 transition-all text-xs font-bold"
          title="Xóa bảng vẽ"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Xóa Bảng</span>
        </button>
      </div>

      {/* Drawing Pad + Text Area Split */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Drawing Pad Canvas */}
        <div className="relative border-2 border-cyan-500/30 rounded-2xl overflow-hidden bg-slate-950 shadow-inner min-h-[200px]">
          <div className="absolute top-2 left-2 text-[10px] bg-slate-900/90 border border-cyan-500/30 px-2.5 py-0.5 rounded-lg text-cyan-300 font-mono pointer-events-none z-10 font-bold">
            Bảng iPad Viết tay / Chuột
          </div>
          <canvas
            ref={canvasRef}
            width={450}
            height={220}
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
            onTouchStart={startDrawing}
            onTouchMove={draw}
            onTouchEnd={stopDrawing}
            className="w-full h-full cursor-crosshair touch-none"
          />
        </div>

        {/* Typed Math Input Box */}
        <div className="flex flex-col space-y-2">
          <label className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
            <Type className="w-3.5 h-3.5 text-cyan-400" />
            <span>Soạn thảo bài giải (Gõ phím & Chèn từ Bảng Equation):</span>
          </label>
          <textarea
            ref={textareaRef}
            value={typedText}
            onChange={(e) => setTypedText(e.target.value)}
            placeholder="Nhập bước giải bài toán XSTK của bạn tại đây... (Ví dụ: \epsilon = 1.96 \cdot \sqrt{\frac{p(1-p)}{n}})"
            className={`w-full flex-1 p-3.5 rounded-2xl border-2 border-cyan-500/40 bg-slate-950 text-white placeholder-slate-400 outline-none focus:border-cyan-400 font-mono text-xs leading-relaxed resize-none ${
              isBold ? 'font-bold' : ''
            } ${isItalic ? 'italic' : ''} ${isUnderline ? 'underline' : ''}`}
            rows={6}
          />
        </div>
      </div>

      {/* EQUATION LIVE PREVIEW AREA */}
      {typedText && (
        <div className="bg-slate-950 border-2 border-emerald-500/40 p-3.5 rounded-2xl space-y-1.5 shadow-[0_0_15px_rgba(16,185,129,0.15)]">
          <div className="flex items-center gap-1.5 text-xs font-black text-emerald-400 uppercase tracking-wide">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400 animate-spin" />
            <span>XEM TRƯỚC CÔNG THỨC TRỰC QUAN THỜI GIAN THỰC (EQUATION LIVE PREVIEW):</span>
          </div>
          <div className="p-3 bg-slate-900 rounded-xl border border-emerald-500/20 text-slate-100 text-xs font-medium leading-relaxed overflow-x-auto">
            <MathText text={typedText} />
          </div>
        </div>
      )}

      {/* Submit Action Button */}
      <div className="flex justify-end pt-1">
        <button
          onClick={handleExport}
          disabled={isSubmitting}
          className="py-3 px-6 bg-gradient-to-r from-cyan-400 via-teal-400 to-emerald-400 hover:from-cyan-300 hover:to-emerald-300 text-slate-950 font-black rounded-2xl shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all flex items-center gap-2 text-xs sm:text-sm cursor-pointer"
        >
          {isSubmitting ? (
            <>
              <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
              <span>AI Tutor đang phân tích bài làm...</span>
            </>
          ) : (
            <>
              <Check className="w-4 h-4 text-slate-950" />
              <span>NỘP BÀI LÀM ĐỂ AI TUTOR CHẤM ĐIỂM</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
